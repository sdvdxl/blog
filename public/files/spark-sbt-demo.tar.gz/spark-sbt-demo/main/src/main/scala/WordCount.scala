import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by sdvdxl on 16/5/11.
  */
object WordCount {
  def main(args: Array[String]) {
    val conf = new SparkConf().setAppName("spark-sbt-demo").setMaster("local[*]")
    val sc  = new SparkContext(conf)
    sc.textFile("main/src/main/scala/WorldCount.scala").flatMap(_.split(" ")).map(word=>(word,1)).reduceByKey(_+_).foreach(println)
    sc.stop()
  }
}
